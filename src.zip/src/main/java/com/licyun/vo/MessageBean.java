package com.licyun.vo;

/**
 * Created by 李呈云
 * Description:
 * 2016/10/7.
 */
public class MessageBean {
    private String email;
    private String message;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
